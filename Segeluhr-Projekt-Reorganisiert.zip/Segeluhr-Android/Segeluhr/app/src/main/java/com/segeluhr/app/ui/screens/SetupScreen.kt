package com.segeluhr.app.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.segeluhr.app.core.GeoPoint
import com.segeluhr.app.data.model.OperationMode
import com.segeluhr.app.ui.components.SectionCard
import com.segeluhr.app.ui.components.WaypointRow
import com.segeluhr.app.ui.theme.Amber
import com.segeluhr.app.ui.theme.Red
import com.segeluhr.app.ui.theme.Teal
import com.segeluhr.app.ui.theme.TextDim
import com.segeluhr.app.ui.theme.Panel2Dark
import com.segeluhr.app.viewmodel.SegeluhrUiState

@Composable
fun SetupScreen(
    state: SegeluhrUiState,
    onSetWaypoint: (String) -> Unit,
    onClearWaypoint: (String) -> Unit,
    onWakeLockChanged: (Boolean) -> Unit,
    onOperationModeChanged: (OperationMode) -> Unit,
    onRequestLocationPermission: () -> Unit,
    onResetAll: () -> Unit,
) {
    Column(
        Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(14.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        SectionCard("Startlinie") {
            WaypointRow("Pin-Ende", fmt(state.pin), { onSetWaypoint("pin") }, { onClearWaypoint("pin") })
            WaypointRow("Boot-Ende", fmt(state.boat), { onSetWaypoint("boat") }, { onClearWaypoint("boat") })
            Text(
                "⚠️ Vorzeichen von Line-Bias hängt von Pin/Boot-Zuordnung ab — einmal mit bekanntem Wind gegenprüfen.",
                fontSize = 12.sp, color = TextDim, modifier = Modifier.padding(top = 6.dp),
            )
        }

        SectionCard("Regatta-Ziel") {
            WaypointRow("Ziel-Wegpunkt", fmt(state.target), { onSetWaypoint("target") }, { onClearWaypoint("target") })
            Text(
                "Wird für Header/Lift-Alarm beim Wind-Tracking verwendet (3× Vibration = Header).",
                fontSize = 12.sp, color = TextDim, modifier = Modifier.padding(top = 6.dp),
            )
        }

        SectionCard("Zuhause / Hafen") {
            WaypointRow("Heimatpunkt", fmt(state.home), { onSetWaypoint("home") }, { onClearWaypoint("home") })
            Text(
                "Wird für die Heimweg-Navigation im Normal-Tab verwendet (Peilung, Wende-Vorschlag, ETA).",
                fontSize = 12.sp, color = TextDim, modifier = Modifier.padding(top = 6.dp),
            )
        }

        SectionCard("Wettfahrt-Bojen (Luv, optional)") {
            WaypointRow("Luvbake (Hauptbake)", fmt(state.competitionMark1), { onSetWaypoint("competitionMark1") }, { onClearWaypoint("competitionMark1") })
            WaypointRow("Entlastungsboje (Halbwind)", fmt(state.competitionMark2), { onSetWaypoint("competitionMark2") }, { onClearWaypoint("competitionMark2") })
            Text(
                "Für den Competition-Modus (startet automatisch beim Startsignal). Ohne gesetzte Luvbake wird sie genau gegen den Wind geschätzt. Die Entlastungsboje ist optional — falls gesetzt, wird nach der Luvbake ein kurzer Halbwind-Schlag dorthin eingeplant.",
                fontSize = 12.sp, color = TextDim, modifier = Modifier.padding(top = 6.dp),
            )
        }

        SectionCard("Betriebsmodus") {
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp), modifier = Modifier.fillMaxWidth()) {
                val modes = listOf(
                    OperationMode.STANDALONE to "Ohne Uhr",
                    OperationMode.WITH_WATCH to "Mit Uhr",
                )
                modes.forEach { (mode, label) ->
                    val active = state.operationMode == mode
                    Button(
                        onClick = { onOperationModeChanged(mode) },
                        colors = ButtonDefaults.buttonColors(
                            containerColor = if (active) Teal else Panel2Dark,
                            contentColor = if (active) Color(0xFF04201C) else TextDim,
                        ),
                        modifier = Modifier.weight(1f),
                    ) { Text(label) }
                }
            }
            Spacer(Modifier.height(10.dp))
            val explanation = when (state.operationMode) {
                OperationMode.STANDALONE ->
                    "Das Handy vibriert selbst (Standalone) und rechnet alles lokal — die Uhr wird nicht gebraucht."
                OperationMode.WITH_WATCH ->
                    if (state.watchConnected) {
                        "✅ Uhr verbunden — GPS und Vibrationsmuster-Kommandos werden per BLE an die T-Watch Ultra gesendet. Das Handy selbst vibriert nicht."
                    } else {
                        "⏳ Noch keine Uhr verbunden — bis die Verbindung steht, vibriert das Handy automatisch als Fallback, damit kein Signal verloren geht."
                    }
            }
            Text(
                explanation, fontSize = 12.sp,
                color = if (state.operationMode == OperationMode.WITH_WATCH && !state.watchConnected) Amber else TextDim,
            )
        }

        SectionCard("Bildschirm") {
            Row(
                Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Text("Display wach halten")
                Switch(checked = state.wakeLockEnabled, onCheckedChange = onWakeLockChanged)
            }
        }

        SectionCard("GPS") {
            if (!state.locationPermissionGranted) {
                Button(onClick = onRequestLocationPermission, modifier = Modifier.fillMaxWidth()) {
                    Text("Standortzugriff erlauben")
                }
            } else {
                Text(
                    if (state.gpsFresh) "GPS aktiv." else "Warte auf GPS-Fix…",
                    fontSize = 13.sp,
                )
            }
        }

        SectionCard("Alles zurücksetzen") {
            var confirming by androidx.compose.runtime.remember { androidx.compose.runtime.mutableStateOf(false) }
            if (!confirming) {
                OutlinedButton(
                    onClick = { confirming = true },
                    colors = ButtonDefaults.outlinedButtonColors(contentColor = Red),
                    modifier = Modifier.fillMaxWidth(),
                ) { Text("Alle Daten löschen") }
            } else {
                Text("Wirklich ALLE Daten (Wegpunkte, Log, Windkalibrierung) löschen?", fontSize = 13.sp, modifier = Modifier.padding(bottom = 8.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button(
                        onClick = { onResetAll(); confirming = false },
                        colors = ButtonDefaults.buttonColors(containerColor = Red),
                        modifier = Modifier.weight(1f),
                    ) { Text("Ja, löschen") }
                    OutlinedButton(onClick = { confirming = false }, modifier = Modifier.weight(1f)) { Text("Abbrechen") }
                }
            }
        }
    }
}

private fun fmt(p: GeoPoint?): String = if (p == null) "nicht gesetzt" else "%.5f, %.5f".format(p.lat, p.lon)
